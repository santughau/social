<!doctype html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width,initial-state=1"/>
        <title>Home Page</title>
        
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="css/default.css" rel="stylesheet" type="text/css" />
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/bootstrap.js"></script>
</head>
    <body>
      
         
       <div class="container-fluid ">
              <div class="row top">
                 <div class="col-md-1"></div>
                  <div class="col-md-3 ">
                     <img src="images/logo1.png" class="img-responsive round">
                  </div>
                  <div class="col-md-8" >
                      <form class="form-inline" style="padding-top:10px;" method="post" action="">
                          <div class="form-group">
                            <label for="exampleInputName2">Email</label>
                            <input type="email" class="form-control"  placeholder="santu.ghau@gmail.com" required="required" name="email">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail2">Password</label>
                            <input type="password" class="form-control"  placeholder="*****" required="required" name="pass">
                          </div>
                          <button type="submit" class="btn btn-default" name="login">Login</button>
                    </form>
                  </div>
              </div>