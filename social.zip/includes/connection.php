<?php
$con = mysqli_connect("localhost","root","","social") or die ("connection was not established");
?>